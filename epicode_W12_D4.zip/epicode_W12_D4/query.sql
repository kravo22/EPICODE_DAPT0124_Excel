-- Non metto Limit nelle query perchè la quantità di dati è piccola --

-- 1. Verificare che i campi definiti come PK siano univoci. --

-- Posso utilizzare due metodi --

-- Metodo 1: non deve restituire nessun valore --

select
	Product_Id,
    count(*) as Conteggio
from
	product
group by
	Product_Id
having
	count(*) > 1;

select
	Sales_Id,
    count(*) as Conteggio
from
	sales
group by
	Sales_Id
having
	count(*) > 1;

select
	Region_Id,
    count(*) as Conteggio
from
	region
group by
	Region_Id
having
	count(*) > 1;

-- Metodo 2: meno elegante, confronto il numero totale di dati nella colonna PK con il numero totale di dati "distinti" della stesa colonna e i due totali devono essere uguali --

select
	count(Product_Id) as Conteggio
from
	product;

select
	count(distinct(Product_Id)) as Conteggio
from
	product;

select
	count(Region_Id) as Conteggio
from
	region;

select
	count(distinct(Region_Id)) as Conteggio
from
	region;

select
	count(Sales_Id) as Conteggio
from
	sales;

select
	count(distinct(Sales_Id)) as Conteggio
from
	sales;

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno --

select
	p.Product_Name as Prodotto,
	year(s.Sales_Date) as Anno,
    sum(s.Total_Price) as Fatturato_Totale_Per_Anno
from
	sales s
join
	product p
on
	s.Product_Id = p.Product_Id
group by 
    p.Product_Name,
    year(s.Sales_Date)
order by
	p.Product_Name;
    
-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente --

select
	r.Region_Name as Regione,
	year(s.Sales_Date) as Anno,
	sum(s.Total_Price) as Fatturato_per_anno
from
	sales s
join
	region r
on
	s.Region_Id = r.Region_Id
group by
	r.Region_Name,
    year(s.Sales_Date)
order by
	year(s.Sales_Date) desc,
    sum(s.Total_Price) desc;
    
-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? --

select
	p.Product_Category as Categoria,
	sum(s.Total_Price) as Fatturato_Totale
from
	product p
join
	sales s
on
	p.Product_Id = s.Product_Id
group by
	p.Product_Category
order by
	sum(s.Total_Price) desc
limit 1;

-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. --

-- Ne ho trovato solamente uno -- 

select
    p.Product_Name as Prodotti
from
	product p
left join
	sales s
on
	p.Product_Id = s.Product_Id
where
	s.Product_Id is null;

-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente). --

select
	p.Product_Name as Prodotti,
	max(s.Sales_Date) as Data_Ultima_Vendita
from
	product p
join
	sales s
on
	p.Product_Id = s.Product_Id
group by
    p.Product_Name
order by
	max(s.Sales_Date) desc;