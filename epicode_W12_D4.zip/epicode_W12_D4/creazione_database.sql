create database Epicode_W12D4;

use Epicode_W12D4;

create table product (
	Product_Id INT PRIMARY KEY,
	Product_Name VARCHAR(50),
	Product_Category VARCHAR(50) -- nell'esercizio non specificava quindi ho lasciato la categoria all'interno della tabella product ma se avessi voluto normalizzare ulteriormente avrei creato un'ulteriore tabella category --
);

create table region (
	Region_Id INT PRIMARY KEY,
	Region_Name VARCHAR(25)
);

create table sales (
	Sales_Id INT AUTO_INCREMENT PRIMARY KEY,
	Product_Id INT,
	Region_Id INT,
	Sales_Date DATE,
	Quantity INT,
	Unit_Price DECIMAL(10,2),
	Total_Price DECIMAL(10,2),
	FOREIGN KEY (Product_Id) REFERENCES product(Product_Id),
	FOREIGN KEY (Region_Id) REFERENCES region(Region_Id)
);

insert into product (Product_Id, Product_Name, Product_Category) values
	(1, 'Pallone', 'Sport'),
	(2, 'Racchetta', 'Sport'),
	(3, 'Frisbee', 'Sport'),
	(4, 'Cluedo', 'Giochi da tavolo'),
	(5, 'Risiko', 'Giochi da tavolo'),
	(6, 'Monopoly', 'Giochi da tavolo'),
	(7, 'The Sims 4', 'Videogames'),
	(8, 'Fifa24', 'Videogames'),
	(9, 'Minecraft', 'Videogames'),
	(10, 'Yo-Yo', 'Altro');

insert into region (Region_Id, Region_Name) values
	(1, 'Nord America'),
	(2, 'Sud America'),
	(3, 'Europa'),
	(4, 'Africa'),
	(5, 'Asia'),
	(6, 'Australia');

insert into sales (Sales_Id, Product_Id, Region_Id, Sales_Date, Quantity, Unit_Price) values
	(1, 10, 1, '2024-01-01', 10, 5.00),
	(2, 2, 2, '2023-01-02', 5, 25.00),
	(3, 3, 3, '2022-01-03', 8, 5.00),
	(4, 4, 4, '2021-01-04', 12, 35.00),
	(5, 5, 5, '2020-01-05', 6, 40.00),
	(6, 6, 1, '2019-01-06', 7, 30.00),
	(7, 7, 2, '2024-01-07', 20, 60.00),
	(8, 8, 3, '2023-02-08', 15, 40.00),
	(9, 9, 4, '2022-02-09', 9, 35.00),
	(10, 10, 5, '2021-02-10', 4, 5.00),
	(11, 10, 2, '2020-02-11', 11, 5.00),
	(12, 2, 3, '2019-02-12', 14, 25.00),
	(13, 3, 4, '2024-02-13', 13, 5.00),
	(14, 4, 5, '2023-02-14', 8, 35.00),
	(15, 5, 1, '2022-03-15', 10, 40.00),
	(16, 6, 2, '2021-03-16', 2, 30.00),
	(17, 7, 3, '2020-03-17', 19, 60.00),
	(18, 8, 4, '2019-03-18', 7, 40.00),
	(19, 9, 5, '2024-03-19', 6, 35.00),
	(20, 10, 1, '2023-03-20', 12, 5.00);
-- ho fatto in modo che ci fossero dei prodotti non venduti e regioni in cui non ci sono vendite --

update sales
set Total_Price = Quantity * Unit_Price
where Total_Price is null;